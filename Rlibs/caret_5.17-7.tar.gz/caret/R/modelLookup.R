
modelLookup <- function(model = NULL)
{
  mods <- c(## ada
            'ada', 'ada', 'ada',
            ## adaboost
            'adaboost', 'adaboost', 'adaboost',
            ## adabag
            'adabag', 
            ## avnnet
            'avNNet', 'avNNet', 'avNNet',               
            ## bag
            'bag', 
            ## bagEarth
            'bagEarth', 'bagEarth', 
            ## bagFDA
            'bagFDA', 'bagFDA',
            ## bayesglm
            'bayesglm',
            ## bdk
            'bdk', 'bdk', 'bdk', 'bdk',
            ## blackboost
            'blackboost', 'blackboost',
            ## Boruta
            'Boruta',
            ## bstTree
            'bstTree', 'bstTree', 'bstTree',
             ## bstLs
            'bstLs', 'bstLs',
             ## bstSm
            'bstSm', 'bstSm',
            ## C5.0
            'C5.0', 'C5.0', 'C5.0',
            ## C5.0Cost
            'C5.0Cost', 'C5.0Cost', 'C5.0Cost', 'C5.0Cost',            
            ## C5.0Tree
            'C5.0Tree',
            ## C5.0Rules
            'C5.0Rules',
            ## cforest
            'cforest', 
            ## ctree
            'ctree', 
            ## ctree2
            'ctree2',
            ## Cubist
            'cubist', 'cubist',            
            ## earth
            'earth', 'earth', 
            ## earthTest
            'earthTest', 'earthTest', 
            ## enet
            'enet', 'enet',
            ## evtree
            'evtree',
            ## extraTrees
            'extraTrees', 'extraTrees',
            ## fda
            'fda', 'fda', 
            ## foba
            'foba', 'foba',
            ## gam
            'gam', 'gam',
            ## gamLoess
            'gamLoess', 'gamLoess',
            ## gamSpline
            'gamSpline',
            ## gamboost
            'gamboost', 'gamboost', 
            ## gaussprLinear
            'gaussprLinear', 
            ## gaussprPoly
            'gaussprPoly', 'gaussprPoly', 
            ## gaussprRadial
            'gaussprRadial', 
            ## gbm
            'gbm', 'gbm', 'gbm',
            ## gcvEarth
            'gcvEarth',
            ## glm
            'glm', 
            ## glmboost
            'glmboost', 'glmboost', 
            ## glmnet
            'glmnet', 'glmnet', 
            ## glmrob
##            'glmrob', 
            ## glmStepAIC
            'glmStepAIC', 
            ## gpls
            'gpls', 
            ## hda
            'hda', 'hda', 'hda', 
            ## hdda
            'hdda', 'hdda', 
            ## icr
            'icr', 
            ## J48
            'J48', 
            ## JRip
            'JRip',
            ## kernelpls
            'kernelpls',
            ## kknn
            'kknn', 'kknn', 'kknn',
            ## knn
            'knn',
            ## krlsRadial
            'krlsRadial', 'krlsRadial',
            ## krlsPoly
            'krlsPoly', 'krlsPoly',
            ## lars
            'lars', 
            ## lars2
            'lars2', 
            ## lasso
            'lasso', 
            ## lda
            'lda',
            ## lda2
            'lda2',
            ## leapForward
            'leapForward',
            ## leapBackward
            'leapBackward',
            ## leapSeq
            'leapSeq',
            ## Linda
            'Linda', 
            ## lm
            'lm', 
            ## lmStepAIC
            'lmStepAIC', 
            ## LMT
            'LMT', 
            ## logforest
            'logforest', 
            ## logicBag
            'logicBag', 'logicBag', 
            ## logitBoost
            'logitBoost', 
            ## logreg
            'logreg', 'logreg',
            ## lrm
            'lrm',
            ## lssvmLinear
            'lssvmLinear', 
            ## lssvmPoly
            'lssvmPoly', 'lssvmPoly', 
            ## lssvmRadial
            'lssvmRadial', 
            ## lvq
            'lvq', 'lvq',
            ## M5
            'M5', 'M5', 'M5',             
            ## M5Rules
            'M5Rules', 'M5Rules', 
            ## mars
            'mars', 'mars', 
            ## mda
            'mda',
            ##Mlda
            'Mlda',
            ## mlp
            'mlp',
            ## mlpWeightDecay
            'mlpWeightDecay', 'mlpWeightDecay',
            ## multinom
            'multinom', 
            ## nb
            'nb', 'nb', 
            ## neuralnet
            'neuralnet', 'neuralnet', 'neuralnet', 
            ## nnet
            'nnet', 'nnet', 
            ## nodeHarvest
            'nodeHarvest', 'nodeHarvest',
            ## obliqueRF
            'ORFridge',
            ## obliqueRF
            'ORFpls',
            ## obliqueRF
            'ORFsvm',
            ## obliqueRF
            'ORFlog',            
            ## obliqueTree
            'obliqueTree', 'obliqueTree', 
            ## OneR
            'OneR', 
            ## pam
            'pam', 
            ## parRF
            'parRF', 
            ## PART
            'PART', 'PART', 
            ## partDSA
            'partDSA', 'partDSA', 
            ## pcaNNet
            'pcaNNet', 'pcaNNet', 
            ## pcr
            'pcr', 
            ## pda
            'pda', 
            ## pda2
            'pda2', 
            ## penalized
            'penalized', 'penalized',
            ## PenalizedLDA
            'PenalizedLDA', 'PenalizedLDA',
            ## plr
            'plr', 'plr', 
            ## pls
            'pls',
            ## pls glm binomial
##            'plsGlmBinomial',
            ## pls glm Gaussian
##            'plsGlmGaussian',
            ## pls glm Gamma
##            'plsGlmGamma',
            ## pls glm Poisson
##            'plsGlmPoisson',            
            ## plsTest
            'plsTest', 
            ## ppr
            'ppr', 
            ## protoclass
            'protoclass', 'protoclass',
            ## qda
            'qda', 
            ## QdaCov
            'QdaCov',
            ## qrnn
            'qrnn', 'qrnn', 'qrnn',
            ## qrf
            'qrf',
            ## rbf
            'rbf',
            ## rbfDDA
            'rbfDDA',
            ## rda
            'rda', 'rda', 
            ## relaxo
            'relaxo', 'relaxo', 
            ## rf
            'rf',
            ## rFerns
            'rFerns',
            ## RFlda
            'RFlda',
            ## ridge reg
            'ridge',
            ## rlm
            'rlm', 
            ## rocc
            'rocc', 
            ## rpart
            'rpart',
            ## rpart2
            'rpart2',
            ## rpartCost
            'rpartCost', 'rpartCost',
            ## RRF
            'RRF', 'RRF', 'RRF',
            ## RRFglobal
            'RRFglobal', 'RRFglobal',
            ## rrlda
            'rrlda', 'rrlda', 'rrlda',
            ## rvmLinear
            'rvmLinear', 
            ## rvmPoly
            'rvmPoly', 'rvmPoly', 
            ## rvmRadial
            'rvmRadial', 
            ## scrda
            ## 'scrda', 'scrda', 
            ## sda
            'sda','sda', 
            ## sddaLDA
            'sddaLDA', 
            ## sddaQDA
            'sddaQDA',
            ## simpls
            'simpls',            
            ## slda
            'slda', 
            ## smda
            'smda', 'smda', 'smda', 
            ## sparseLDA
            'sparseLDA', 'sparseLDA', 
            ## spls
            'spls', 'spls', 'spls', 
            ## stepLDA
            'stepLDA', 'stepLDA', 
            ## stepQDA
            'stepQDA', 'stepQDA', 
            ## superpc
            'superpc', 'superpc', 
            ## svmLinear
            'svmLinear', 
            ## svmpoly
            'svmpoly', 'svmpoly', 'svmpoly', 
            ## svmPoly
            'svmPoly', 'svmPoly', 'svmPoly', 
            ## svmradial
            'svmradial', 'svmradial', 
            ## svmRadial
            'svmRadial', 'svmRadial',
            ## svmRadialCost
            'svmRadialCost',  
            ## svmRadialWeights
            'svmRadialWeights', 'svmRadialWeights', 'svmRadialWeights',            
            ## treebag
            'treebag', 
            ## vbmpRadial
            'vbmpRadial',
            ## widekernelpls
            'widekernelpls',
            ## xyf
            'xyf', 'xyf', 'xyf', 'xyf')

  pNames <- c(## ada
              'iter', 'maxdepth', 'nu',
              ## adaboost
              'mfinal', 'cp', 'coeflearn',
              ## adabag
              'cp',               
              ## avnnet
              'size', 'decay', 'bag',              
              ## bag
              'vars', 
              ## bagEarth
              'nprune', 'degree', 
              ## bagFDA
              'nprune', 'degree',
              ## bayesglm
              'parameter',
              ## bdk
              'xdim', 'ydim', 'topo', 'xweight',              
              ## blackboost
              'mstop', 'maxdepth',
              ## Boruta
              'mtry',
              ## bstTree
              'mstop', 'maxdepth', 'nu',
              ## bstLs
              'mstop', 'nu',
              ## bstSm
              'mstop', 'nu',
              ## C5.0
              'trials', 'model', 'winnow',
              ## C5.0Cost
              'trials', 'model', 'winnow', 'Cost',              
              ## C5.0Tree
              'parameter',
              ## C5.0Rules
              'parameter',
              ## cforest
              'mtry', 
              ## ctree
              'mincriterion', 
              ## ctree2
              'maxdepth',
              ## Cubist
              'committees', 'neighbors', 
              ## earth
              'nprune', 'degree', 
              ## earthTest
              'nprune', 'degree', 
              ## enet
              'fraction', 'lambda',
              ## evtree
              'alpha',
              ## extraTrees
              'mtry', 'numRandomCuts',
              ## fda
              'nprune', 'degree', 
              ## foba
              'k', 'lambda',
              ## gam
              'select', 'method',
              ## gamLoess
              'span', 'degree',
              ## gamSpline
              'df',
              ## gamboost
              'mstop', 'prune', 
              ## gaussprLinear
              'parameter', 
              ## gaussprPoly
              'degree', 'scale', 
              ## gaussprRadial
              'sigma', 
              ## gbm
              'n.trees', 'interaction.depth', 'shrinkage',
              ## gcvEarth
              'degree',
              ## glm
              'parameter', 
              ## glmboost
              'mstop', 'prune', 
              ## glmnet
              'lambda', 'alpha', 
              ## glmrob
##              'parameter', 
              ## glmStepAIC
              'parameter', 
              ## gpls
              'K.prov', 
              ## hda
              'gamma', 'lambda', 'newdim', 
              ## hdda
              'threshold', 'model', 
              ## icr
              'n.comp', 
              ## J48
              'C', 
              ## JRip
              'NumOpt',
              ## kernelpls
              'ncomp',
              ## kknn
              'kmax', 'distance', 'kernel',
              ## knn
              'k',
              ## krlsRadial
              'lambda', 'sigma',
              ## krlsPoly
              'lambda', 'degree',
              ## lars
              'fraction', 
              ## lars2
              'step', 
              ## lasso
              'fraction', 
              ## lda
              'parameter',
              ## lda
              'dimen',
              ## leapForward
              'nvmax',
              ## leapBackward
              'nvmax',
              ## leapSeq
              'nvmax',
              ## Linda
              'parameter', 
              ## lm
              'parameter', 
              ## lmStepAIC
              'parameter', 
              ## LMT
              'iter', 
              ## logforest
              'parameter', 
              ## logicBag
              'nleaves', 'ntrees', 
              ## logitBoost
              'nIter', 
              ## logreg
              'treesize', 'ntrees',
              ## lrm
              'parameter',
              ## lssvmLinear
              'parameter', 
              ## lssvmPoly
              'degree', 'scale', 
              ## lssvmRadial
              'sigma', 
              ## lvq
              'size', 'k',
              ## M5
              'pruned', 'smoothed', 'rules',
              ## M5Rules
              'pruned', 'smoothed', 
              ## mars
              'nprune', 'degree', 
              ## mda
              'subclasses',
              ## Mlda
              'parameter',
              ## mlp
              'size',
              ## mlpWeightDecay
              'size', 'decay',
              ## multinom
              'decay', 
              ## nb
              'fL', 'usekernel', 
              ## neuralnet
              'layer1', 'layer2', 'layer3', 
              ## nnet
              'size', 'decay', 
              ## nodeHarvest
              'maxinter', 'mode',
              ## obliqueRF
              'mtry',
              'mtry',
              'mtry',
              'mtry',
              ## obliqueTree
              'oblique.splits', 'variable.selection', 
              ## OneR
              'parameter', 
              ## pam
              'threshold', 
              ## parRF
              'mtry', 
              ## PART
              'threshold', 'pruned', 
              ## partDSA
              'cut.off.growth', 'MPD', 
              ## pcaNNet
              'size', 'decay', 
              ## pcr
              'ncomp', 
              ## pda
              'lambda', 
              ## pda2
              'df', 
              ## penalized
              'lambda1', 'lambda2',
              ## PenalizedLDA
              'lambda', 'K',
              ## plr
              'lambda', 'cp', 
              ## pls
              'ncomp',
              ## pls glm binomial
##              'nt',   
              ## pls glm Gaussian
##              'nt',   
              ## pls glm Gamma
##              'nt',   
              ## pls glm Poisson
##              'nt',   
              ## plsTest
              'ncomp', 
              ## ppr
              'nterms',
              ## protoclass
              'eps', 'Minkowski',
              ## qda
              'parameter', 
              ## QdaCov
              'parameter',
              ## qrnn
              'n.hidden', 'penalty', 'bag',              
              ## qrf
              'mtry',
              ## rbf
              'size',
              ## rbfDDA
              'negativeThreshold',
              ## rda
              'gamma', 'lambda', 
              ## relaxo
              'lambda', 'phi', 
              ## rf
              'mtry',
              ## rFerns
              'depth',
              ## RFlda
              'q',
              ## ridge
              'lambda',
              ## rlm
              'parameter', 
              ## rocc
              'xgenes', 
              ## rpart
              'cp',
              ## rpart2
              'maxdepth',
              ## rpartCost
              'cp', 'Cost',
              ## RRF
              'mtry', 'coefReg', 'coefImp',
              ## RRFglobal
              'mtry', 'coefReg',
              ## rrlda
              'lambda', 'hp', 'penalty',
              ## rvmLinear
              'parameter', 
              ## rvmPoly
              'degree', 'scale', 
              ## rvmRadial
              'sigma', 
              ## scrda
              ## 'alpha', 'delta', 
              ## sda
              'diagonal','lambda', 
              ## sddaLDA
              'parameter', 
              ## sddaQDA
              'parameter',
              ## simpls
              'ncomp',              
              ## slda
              'parameter', 
              ## smda
              'NumVars', 'R', 'lambda', 
              ## sparseLDA
              'NumVars', 'lambda', 
              ## spls
              'K', 'eta', 'kappa', 
              ## stepLDA
              'maxvar', 'direction', 
              ## stepQDA
              'maxvar', 'direction', 
              ## superpc
              'threshold', 'n.components', 
              ## svmLinear
              'C', 
              ## svmpoly
              'C', 'degree', 'scale', 
              ## svmPoly
              'C', 'degree', 'scale', 
              ## svmradial
              'C', 'sigma', 
              ## svmRadial
              'C', 'sigma',
              ## svmRadialCost
              'C',    
              ## svmRadialWeights
              'C', 'sigma', "Weight",
              ## treebag
              'parameter', 
              ## vbmpRadial
              'estimateTheta',
              ## widekernelpls
              'ncomp',
              ## xyf
              'xdim', 'ydim', 'topo', 'xweight')


  pLabel <- c(## ada
              '#Trees',
              'Max Tree Depth',
              'Learning Rate',
              ## adaboost
              '#Trees', 
              'Complexity Parameter', 
              'Weighting Scheme',
              ## adabag
              'Complexity Parameter',               
              ## avnnet
              '#Hidden Units',
              'Weight Decay',
              'Bagging',
              ## bag
              '#Randomly Selected Predictors',
              ## bagEarth
              '#Terms',
              'Product Degree',
              ## bagFDA
              '#Terms',
              'Product Degree',
              ## bayesglm
              'none',
              ## bdk
              'Rows', 'Columns', 'Topology', 'X Weight',
              ## blackboost
              '#Trees',
              'Max Tree Depth',
              ## Boruta
              '#Randomly Selected Predictors',
              ## bstTree
              '# Boosting Iterations', 'Max Tree Depth', 'Shrinkage',
              ## bstLs
              '# Boosting Iterations', 'Shrinkage',
              ## bstSm
              '# Boosting Iterations', 'Shrinkage',
              ## C5.0
              '# Boosting Iterations', 'Model Type', 'Winnow',
              ## C5.0Cost
              '# Boosting Iterations', 'Model Type', 'Winnow', 'Cost',              
               ## C5.0Tree
              'none',
              ## C5.0Rules
              'none',
              ## cforest
              '#Randomly Selected Predictors',
              ## ctree
              '1 - P-Value Threshold',
              ## ctree2
              'Max Tree Depth',
              ## Cubist
              '#Committees', '#Instances', 
              ## earth
              '#Terms',
              'Product Degree',
              ## earthTest
              '#Terms',
              'Product Degree',
              ## enet
              'Fraction of Full Solution',
              'Weight Decay',
              ## evtree
              "Complexity Parameter",
              ## extraTrees
              '# Randomly Selected Predictors',
              '# Random Cuts',
              ## fda
              '#Terms',
              'Product Degree',
              ## foba
              '#Variables Retained',
              'L2 Penalty',
              ## gam
              'Feature Selection', 'Method',
              ## gamLoess
              'Span', 'Degree',
              ## gamSpline
              'Degrees of Freedom',
              ## gamboost
              '# Boosting Iterations',
              'AIC Prune?',
              ## gaussprLinear
              'none',
              ## gaussprPoly
              'Polynomial Degree',
              'Scale',
              ## gaussprRadial
              'Sigma',
              ## gbm
              '#Trees',
              'Interaction Depth',
              'Learning Rate',
              ## gcvEarth
              '#Terms',
              ## glm
              'none',
              ## glmboost
              '# Boosting Iterations',
              'AIC Prune?',
              ## glmnet
              'Regularization Parameter',
              'Mixing Percentage',
              ## glmrob
##              'none',
              ## glmStepAIC
              'none',
              ## gpls
              '#Components',
              ## hda
              'Gamma',
              'Lambda',
              'Dimension of the Discriminative Subspace',
              ## hdda
              'Threshold',
              'Model Type',
              ## icr
              '#Components',
              ## J48
              'Confidence Threshold',
              ## JRip
              '# Optimizations',
              ## kernelpls
              '#Components',
              ## kknn
              'Max. #Neighbors', 'Distance', 'Kernel',
              ## knn
              '#Neighbors',
              ## krlsRadial
              'Regularization Parameter',
              'Sigma',
              ## krlsPoly
              'Regularization Parameter',
              "Polynomial Degree",
              ## lars
              'Fraction',
              ## lars2
              '#Steps',
              ## lasso
              'Fraction of Full Solution',
              ## lda
              'none',
              ## lda2
              '#Discriminant Functions',
              ## leapForward
              'Maximum Size of Subsets',
              ## leapBackward
              'Maximum Size of Subsets',
              ## leapSeq
              'Maximum Size of Subsets',
              ## Linda
              'none',
              ## lm
              'none',
              ## lmStepAIC
              'none',
              ## LMT
              '# Iteratons',
              ## logforest
              'none',
              ## logicBag
              'Maximum Number of Leaves',
              'Number of Trees',
              ## logitBoost
              '# Boosting Iterations',
              ## logreg
              'Maximum Number of Leaves',
              'Number of Trees',
              ## lrm
              'none',
              ## lssvmLinear
              'none',
              ## lssvmPoly
              'Polynomial Degree',
              'Scale',
              ## lssvmRadial
              'Sigma',
              ## lvq
              'Codebook Size', '#Prototypes',
              ## M5
              'Pruned', 'Smoothed', 'Rules',
              ## M5Rules
              'Pruned', 'Smoothed',
              ## mars
              '#Terms',
              'Product Degree',
              ## mda
              '#Subclasses Per Class',
              ## Mlda
              'none',
              ## mlp
              '#Hidden Units',
              ## mlpWeightDecay
              '#Hidden Units',
              'Weight Decay',              
              ## multinom
              'Weight Decay',
              ## nb
              'Laplace Correction', 'Distribution Type',
              ## neuralnet
              '#Hidden Units in Layer 1',
              '#Hidden Units in Layer 2',
              '#Hidden Units in Layer 3',
              ## nnet
              '#Hidden Units',
              'Weight Decay',
              ## nodeHarvest
              'Maximum Interaction Depth',
              'Prediction Mode',
              ## obliqueRF
              '# Randomly Selected Predictors',
              '# Randomly Selected Predictors',
              '# Randomly Selected Predictors',
              '# Randomly Selected Predictors',            
              ## obliqueTree
              'Oblique Splits',
              'Variable Selection Method',
              ## OneR
              'none',
              ## pam
              'Shrinkage Threshold',
              ## parRF
              '#Randomly Selected Predictors',
              ## PART
              'Confidence Threshold',
              'Pruning',
              ## partDSA
              'Number of Terminal Partitions',
              'Minimum Percent Difference',
              ## pcaNNet
              '#Hidden Units',
              'Weight Decay',
              ## pcr
              '#Components',
              ## pda
              'Shrinkage Penalty Coefficient',
              ## pda2
              'Degrees of Freedom',
              ## penalized
              'L1 Penalty',
              'L2 Penalty',
              ## PenalizedLDA
              'L1 Penalty',
              '#Discriminant Functions',
              ## plr
              'L2 Penalty',
              'Complexity Parameter',
              ## pls
              '#Components',
              ## pls glm binomial
##              '#Components',
              ## pls glm Gaussian
##              '#Components',
              ## pls glm Gamma
##              '#Components',
              ## pls glm Poisson
##              '#Components',      
              ## plsTest
              '#Components',
              ## ppr
              '# Terms',
              ## protoclass
              'Ball Size', 'Distance Order',
              ## qda
              'none',
              ## QdaCov
              'none',
              ## qrnn
              '#Hidden Units', ' Weight Decay', 'Bagged Models?',                     
              ## qrf
              '#Randomly Selected Predictors',
              ## rbf
              '#Hidden Units',
              ## rbfDDA
              'Activation Limit for Conflicting Classes',
              ## rda
              'Gamma',
              'Lambda',
              ## relaxo
              'Penalty Parameter',
              'Relaxation Parameter',
              ## rf
              '#Randomly Selected Predictors',
              ## rFerns
              'Fern Depth',
              ## RFlda
              "# Factors",
              ## ridge
              'Penalty',
              ## rlm
              'none',
              ## rocc
              '#Variables Retained',
              ## rpart
              'Complexity Parameter',
              ## rpart2
              'Max Tree Depth',
              ## rpartCost
              'Complexity Parameter', 'Cost',
              ## RRF
              '#Randomly Selected Predictors',
              'Regularization Value',
              'Importance Coefficient',
              ## RRFglobal
              '#Randomly Selected Predictors',
              'Regularization Value',
              ## rrlda
              'Penalty Parameter',
              'Robustness Parameter',
              'Penalty Type',
              ## rvmLinear
              'none',
              ## rvmPoly
              'Polynomial Degree',
              'Scale',
              ## rvmRadial
              'Sigma',
              ## scrda
              ## 'Regularization Value',
              ## 'Threshold',
              ## sda
              'Diagonalize','shrinkage',
              ## sddaLDA
              'none',
              ## sddaQDA
              'none',
              ## simpls
              '#Components',              
              ## slda
              'none',
              ## smda
              '# Predictors',
              '# Subclasses',
              'Lambda',
              ## sparseLDA
              '# Predictors',
              'Lambda',
              ## spls
              '#Components',
              'Threshold',
              'Kappa',
              ## stepLDA
              'Maximum #Variables',
              'Search Direction',
              ## stepQDA
              'Maximum #Variables',
              'Search Direction',
              ## superpc
              'Threshold',
              '#Components',
              ## svmLinear
              'C',
              ## svmpoly
              'Cost',
              'Polynomial Degree',
              'Scale',
              ## svmPoly
              'Cost',
              'Polynomial Degree',
              'Scale',
              ## svmradial
              'Cost',
              'Sigma',
              ## svmRadial
              'Cost',
              'Sigma',
              ## svmRadialCost
              'Cost',
              ## svmRadialWeights
              'Cost', 'Sigma', 'Class Weight',
              ## treebag
              'none',
              ## vbmpRadial
              'Theta Estimated',
              ## widekernelpls
              '#Components',
              ## xyf
              'Rows', 'Columns', 'Topology', 'X Weight'
              )

  isSeq <- c(## ada
             FALSE, FALSE, FALSE,
             ## adaboost
             TRUE, FALSE, FALSE,
             ## adabag
             FALSE, 
             ## avnnet
             FALSE, FALSE, FALSE,             
             ## bag
             FALSE, 
             ## bagEarth
             FALSE, FALSE, 
             ## bagFDA
             FALSE, FALSE,
             ## bayesglm
             FALSE,
             ## bdk
             FALSE, FALSE, FALSE, FALSE,
             ## blackboost
             TRUE, FALSE,
             ## Boruta
             FALSE,
             ## bstTree
             TRUE, FALSE, FALSE,
             ## bstLm
             TRUE, FALSE,
             ## bstSm
             TRUE, FALSE,
             ## C5.0
             TRUE, FALSE, FALSE,
             ## C5.0Cost
             TRUE, FALSE, FALSE, FALSE,             
             ## C5.0Tree
             FALSE,
             ## C5.0Rules
             FALSE,
             ## cforest
             FALSE, 
             ## ctree actually is a sequential model, but treeresponse can't do probs from multiple models
             FALSE, 
             ## ctree2
             FALSE,
             ## Cubist
             FALSE, TRUE, 
             ## earth
             TRUE, FALSE, 
             ## earthTest
             FALSE, FALSE, 
             ## enet
             TRUE, FALSE,
             ## evtree
             FALSE,
             ## extraTrees
             FALSE, FALSE,
             ## fda
             FALSE, FALSE, 
             ## foba
             TRUE, FALSE,
             ## gam
             FALSE, FALSE,
             ## gamLoess
             FALSE, FALSE,
             ## gamSpline
             FALSE,
             ## gamboost
             TRUE, FALSE, 
             ## gaussprLinear
             FALSE, 
             ## gaussprPoly
             FALSE, FALSE, 
             ## gaussprRadial
             FALSE, 
             ## gbm
             TRUE, FALSE, FALSE,
             ## gcvEarth
             FALSE,
             ## glm
             FALSE, 
             ## glmboost
             TRUE, FALSE, 
             ## glmnet
             TRUE, FALSE, 
             ## glmrob
##             FALSE, 
             ## glmStepAIC
             FALSE, 
             ## gpls
             FALSE, 
             ## hda
             FALSE, FALSE, FALSE, 
             ## hdda
             FALSE, FALSE, 
             ## icr
             FALSE, 
             ## J48
             FALSE, 
             ## JRip
             FALSE,
             ## kernelpls
             TRUE,
             ## kknn
             FALSE, FALSE, FALSE,
             ## knn
             FALSE,
             ## krlsRadial
             FALSE, FALSE,
             ## krlsPoly
             FALSE, FALSE,
             ## lars
             TRUE, 
             ## lars2
             TRUE, 
             ## lasso
             TRUE, 
             ## lda
             FALSE,
             ## lda2
             TRUE,
             ## leapForward
             TRUE,
             ## leapBackward
             TRUE,
             ## leapSeq
             TRUE,
             ## Linda
             FALSE, 
             ## lm
             FALSE, 
             ## lmStepAIC
             FALSE, 
             ## LMT
             FALSE, 
             ## logforest
             FALSE, 
             ## logicBag
             FALSE, FALSE, 
             ## logitBoost
             TRUE, 
             ## logreg
             FALSE, FALSE,
             ## lrm
             FALSE,
             ## lssvmLinear
             FALSE, 
             ## lssvmPoly
             FALSE, FALSE, 
             ## lssvmRadial
             FALSE, 
             ## lvq
             FALSE, FALSE,
             ## M5
             FALSE, FALSE, FALSE,           
             ## M5Rules
             FALSE, FALSE, 
             ## mars
             FALSE, FALSE, 
             ## mda
             FALSE,
             ## Mlda
             FALSE,
             ## mlp
             FALSE,
             ## mlpWeightDecay
             FALSE, FALSE,
             ## multinom
             FALSE, 
             ## nb
             FALSE, FALSE, 
             ## neuralnet
             FALSE, FALSE, FALSE, 
             ## nnet
             FALSE, FALSE, 
             ## nodeHarvest
             FALSE, FALSE,
             ## obliqueRF
             FALSE,
             FALSE,
             FALSE,
             FALSE,
             ## obliqueTree
             FALSE, FALSE, 
             ## OneR
             FALSE, 
             ## pam
             TRUE, 
             ## parRF
             FALSE, 
             ## PART
             FALSE, FALSE, 
             ## partDSA
             TRUE, FALSE, 
             ## pcaNNet
             FALSE, FALSE, 
             ## pcr
             TRUE, 
             ## pda
             FALSE, 
             ## pda2
             FALSE, 
             ## penalized
             FALSE, FALSE,
             ## PenalizedLDA
             FALSE, TRUE,
             ## plr
             FALSE, FALSE, 
             ## pls
             TRUE,
             ## pls glm binomial
##             FALSE,
             ## pls glm Gaussian
##             FALSE,
             ## pls glm Gamma
##             FALSE,
             ## pls glm Poisson
##             FALSE,                
             ## plsTest
             FALSE, 
             ## ppr
             FALSE,
             ## protoclass
             FALSE, FALSE,
             ## qda
             FALSE, 
             ## QdaCov
             FALSE,
             ## qrnn
             FALSE, FALSE, FALSE,                 
             ## qrf
             FALSE,
             ## rbf
             FALSE,
             ## rbfDDA
             FALSE,
             ## rda
             FALSE, FALSE, 
             ## relaxo
             TRUE, FALSE, 
             ## rf
             FALSE,
             ## rFerns
             FALSE,
             ## RFlda
             FALSE,
             ## ridge
             FALSE,
             ## rlm
             FALSE, 
             ## rocc
             FALSE, 
             ## rpart
             TRUE,             
             ## rpart2
             TRUE,
             ## rpartCost
             TRUE, TRUE,
             ## RRF
             FALSE, FALSE, FALSE,
             ## RRFglobal
             FALSE, FALSE,
             ## rrlda
             FALSE, FALSE, FALSE,
             ## rvmLinear
             FALSE, 
             ## rvmPoly
             FALSE, FALSE, 
             ## rvmRadial
             FALSE, 
             ## scrda
             ## TRUE, TRUE, 
             ## sda
             FALSE, FALSE,
             ## sddaLDA
             FALSE, 
             ## sddaQDA
             FALSE,
             ## simpls
             TRUE,             
             ## slda
             FALSE, 
             ## smda
             FALSE, FALSE, FALSE, 
             ## sparseLDA
             FALSE, FALSE, 
             ## spls
             FALSE, FALSE, FALSE, 
             ## stepLDA
             FALSE, FALSE, 
             ## stepQDA
             FALSE, FALSE, 
             ## superpc
             TRUE, TRUE, 
             ## svmLinear
             FALSE, 
             ## svmpoly
             FALSE, FALSE, FALSE, 
             ## svmPoly
             FALSE, FALSE, FALSE, 
             ## svmradial
             FALSE, FALSE, 
             ## svmRadial
             FALSE, FALSE,
             ## svmRadialCost
             FALSE,  
             ## svmRadialWeights
             FALSE, FALSE, FALSE,
             ## treebag
             FALSE, 
             ## vbmpRadial
             FALSE,
             ## widekernelpls
             TRUE,
             ## xyf
             FALSE, FALSE, FALSE, FALSE
             )
  isRegMod <- c(## ada
                FALSE, FALSE, FALSE,
                ## adaboost
                FALSE, FALSE, FALSE,
                ## adabag
                FALSE,                 
                ## avnnet
                TRUE, TRUE, TRUE,                 
                ## bag
                TRUE, 
                ## bagEarth
                TRUE, TRUE, 
                ## bagFDA
                FALSE, FALSE,
                ## bayesglm
                TRUE,
                ## bdk
                TRUE, TRUE, TRUE, TRUE,
                ## blackboost
                TRUE, TRUE,
                ## Boruta
                TRUE,
                ## bstTree
                TRUE, TRUE, TRUE,
                ## bstLm
                TRUE, TRUE,
                ## bstSm
                TRUE, TRUE,
                ## C5.0
                FALSE, FALSE, FALSE,
                ## C5.0Cost
                FALSE, FALSE, FALSE, FALSE,                
                ## C5.0Tree
                FALSE,
                ## C5.0Rules
                FALSE,
                ## cforest
                TRUE, 
                ## ctree
                TRUE, 
                ## ctree2
                TRUE,
                ## Cubist
                TRUE, TRUE,
                ## earth
                TRUE, TRUE, 
                ## earthTest
                TRUE, TRUE, 
                ## enet
                TRUE, TRUE,
                ## evtree
                TRUE,
                ## extraTrees
                TRUE, TRUE,
                ## fda
                FALSE, FALSE, 
                ## foba
                TRUE, TRUE,
                ## gam
                TRUE, TRUE,
                ## gamLoess
                TRUE, TRUE,
                ## gamSpline
                TRUE,
                ## gamboost
                TRUE, TRUE, 
                ## gaussprLinear
                TRUE, 
                ## gaussprPoly
                TRUE, TRUE, 
                ## gaussprRadial
                TRUE, 
                ## gbm
                TRUE, TRUE, TRUE,
                ## gcvEarth
                TRUE,
                ## glm
                TRUE, 
                ## glmboost
                TRUE, TRUE, 
                ## glmnet
                TRUE, TRUE, 
                ## glmrob
##                TRUE, 
                ## glmStepAIC
                TRUE, 
                ## gpls
                FALSE, 
                ## hda
                FALSE, FALSE, FALSE, 
                ## hdda
                FALSE, FALSE, 
                ## icr
                TRUE, 
                ## J48
                FALSE, 
                ## JRip
                FALSE,
                ## kernelpls
                TRUE,
                ## kknn
                TRUE, TRUE, TRUE,
                ## knn
                TRUE,
                ## krlsRadial
                TRUE, TRUE,
                ## krlsPoly
                TRUE, TRUE,
                ## lars
                TRUE, 
                ## lars2
                TRUE, 
                ## lasso
                TRUE, 
                ## lda
                FALSE,
                ## lda
                FALSE,
                ## leapForward
                TRUE,
                ## leapBackward
                TRUE,
                ## leapSeq
                TRUE,
                ## Linda
                FALSE, 
                ## lm
                TRUE, 
                ## lmStepAIC
                TRUE, 
                ## LMT
                FALSE, 
                ## logforest
                FALSE, 
                ## logicBag
                TRUE, TRUE, 
                ## logitBoost
                FALSE, 
                ## logreg
                TRUE, TRUE,
                ## lrm
                FALSE,
                ## lssvmLinear
                FALSE, 
                ## lssvmPoly
                FALSE, FALSE, 
                ## lssvmRadial
                FALSE, 
                ## lvq
                FALSE, FALSE,
                ## M5
                TRUE, TRUE, TRUE,                
                ## M5Rules
                TRUE, TRUE,
                ## mars
                TRUE, TRUE, 
                ## mda
                FALSE,
                ## Mlda
                FALSE,
                ## mlp
                TRUE,
                ## mlpWeightDecay
                TRUE, TRUE,
                ## multinom
                FALSE, 
                ## nb
                FALSE, FALSE, 
                ## neuralnet
                TRUE, TRUE, TRUE, 
                ## nnet
                TRUE, TRUE, 
                ## nodeHarvest
                TRUE, TRUE,
                ## obliqueRF
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                ## obliqueTree
                FALSE, FALSE, 
                ## OneR
                FALSE, 
                ## pam
                FALSE, 
                ## parRF
                TRUE, 
                ## PART
                FALSE, FALSE, 
                ## partDSA
                TRUE, TRUE, 
                ## pcaNNet
                TRUE, TRUE, 
                ## pcr
                TRUE, 
                ## pda
                FALSE, 
                ## pda2
                FALSE, 
                ## penalized
                TRUE, TRUE,
                ## PenalizedLDA
                FALSE, FALSE,
                ## plr
                FALSE, FALSE, 
                ## pls
                TRUE,
                ## pls glm binomial
##                FALSE,
                ## pls glm Gaussian
##                TRUE,
                ## pls glm Gamma
##                TRUE,
                ## pls glm Poisson
##                TRUE,                          
                ## plsTest
                TRUE, 
                ## ppr
                TRUE, 
                ## protoclass
                FALSE, FALSE,
                ## qda
                FALSE, 
                ## QdaCov
                FALSE,
                ## qrnn
                TRUE, TRUE, TRUE,                
                ## qrf
                TRUE,
                ## rbf
                FALSE,
                ## rbfDDA
                TRUE,
                ## rda
                FALSE, FALSE, 
                ## relaxo
                TRUE, TRUE, 
                ## rf
                TRUE,
                ## rFerns
                FALSE,
                ## RFlda
                FALSE,
                ## ridge
                TRUE,
                ## rlm
                TRUE, 
                ## rocc
                FALSE, 
                ## rpart
                TRUE,                
                ## rpart2
                TRUE,
                ## rpartCost
                FALSE, FALSE,
                ## RRF
                TRUE, TRUE, TRUE,
                ## RRFglobal
                TRUE, TRUE,
                ## rrlda
                FALSE, FALSE, FALSE,
                ## rvmLinear
                TRUE, 
                ## rvmPoly
                TRUE, TRUE, 
                ## rvmRadial
                TRUE, 
                ## scrda
                ## FALSE, FALSE, 
                ## sda
                FALSE, FALSE,
                ## sddaLDA
                FALSE, 
                ## sddaQDA
                FALSE,
                ## simpls
                TRUE,                
                ## slda
                FALSE, 
                ## smda
                FALSE, FALSE, FALSE, 
                ## sparseLDA
                FALSE, FALSE, 
                ## spls
                TRUE, TRUE, TRUE, 
                ## stepLDA
                FALSE, FALSE, 
                ## stepQDA
                FALSE, FALSE, 
                ## superpc
                TRUE, TRUE, 
                ## svmLinear
                TRUE, 
                ## svmpoly
                TRUE, TRUE, TRUE, 
                ## svmPoly
                TRUE, TRUE, TRUE, 
                ## svmradial
                TRUE, TRUE, 
                ## svmRadial
                TRUE, TRUE, 
                ## svmRadialCost
                TRUE,
                ## svmRadialWeights
                FALSE, FALSE, FALSE,
                ## treebag
                TRUE, 
                ## vbmpRadial
                FALSE,
                ## widekernelpls
                TRUE,
                ## xyf
                TRUE, TRUE, TRUE, TRUE
                )

  isClassMod <- c(## ada
                  TRUE, TRUE, TRUE,
                  ## adaboost
                  TRUE, TRUE, TRUE,
                  ## adabag
                  TRUE,                   
                  ## avnnet
                  TRUE, TRUE, TRUE,                  
                  ## bag
                  TRUE, 
                  ## bagEarth
                  TRUE, TRUE, 
                  ## bagFDA
                  TRUE, TRUE,
                  ## bayesglm
                  TRUE,
                  ## bdk
                  TRUE, TRUE, TRUE, TRUE,
                  ## blackboost
                  TRUE, TRUE,
                  ## Boruta
                  TRUE,
                  ## bstTree
                  TRUE, TRUE, TRUE,
                  ## bstLm
                  TRUE, TRUE,
                  ## bstSm
                  TRUE, TRUE,
                  ## C5.0
                  TRUE, TRUE, TRUE,
                  ## C5.0Cost
                  TRUE, TRUE, TRUE, TRUE,                 
                  ## C5.0Tree
                  TRUE,
                  ## C5.0Rules
                  TRUE,
                  ## cforest
                  TRUE, 
                  ## ctree
                  TRUE, 
                  ## ctree2
                  TRUE,
                  ## Cubist
                  FALSE, FALSE,
                  ## earth
                  TRUE, TRUE, 
                  ## earthTest
                  FALSE, FALSE, 
                  ## enet
                  FALSE, FALSE,
                  ## evtree
                  TRUE,
                  ## extraTrees
                  TRUE, TRUE,
                  ## fda
                  TRUE, TRUE, 
                  ## foba
                  FALSE, FALSE,
                  ## gam
                  TRUE, TRUE,
                  ## gamLoess
                  TRUE, TRUE,
                  ## gamSpline
                  TRUE,
                  ## gamboost
                  TRUE, TRUE, 
                  ## gaussprLinear
                  TRUE, 
                  ## gaussprPoly
                  TRUE, TRUE, 
                  ## gaussprRadial
                  TRUE, 
                  ## gbm
                  TRUE, TRUE, TRUE,
                  ## gcvEarth
                  TRUE,
                  ## glm
                  TRUE, 
                  ## glmboost
                  TRUE, TRUE, 
                  ## glmnet
                  TRUE, TRUE, 
                  ## glmrob
##                  TRUE, 
                  ## glmStepAIC
                  TRUE, 
                  ## gpls
                  TRUE, 
                  ## hda
                  TRUE, TRUE, TRUE, 
                  ## hdda
                  TRUE, TRUE, 
                  ## icr
                  FALSE, 
                  ## J48
                  TRUE, 
                  ## JRip
                  TRUE,
                  ## kernelpls
                  TRUE,
                  ## kknn
                  TRUE, TRUE, TRUE,
                  ## knn
                  TRUE,
                  ## krlsRadial
                  FALSE, FALSE,
                  ## krlsPoly
                  FALSE, FALSE,
                  ## lars
                  FALSE, 
                  ## lars2
                  FALSE, 
                  ## lasso
                  FALSE, 
                  ## lda
                  TRUE,
                  ## lda
                  TRUE,
                  ## leapForward
                  FALSE,
                  ## leapBackward
                  FALSE,
                  ## leapSeq
                  FALSE,
                  ## Linda
                  TRUE, 
                  ## lm
                  FALSE, 
                  ## lmStepAIC
                  FALSE, 
                  ## LMT
                  TRUE, 
                  ## logforest
                  TRUE, 
                  ## logicBag
                  TRUE, TRUE, 
                  ## logitBoost
                  TRUE, 
                  ## logreg
                  TRUE, TRUE,
                  ## lrm
                  TRUE,
                  ## lssvmLinear
                  TRUE, 
                  ## lssvmPoly
                  TRUE, TRUE, 
                  ## lssvmRadial
                  TRUE, 
                  ## lvq
                  TRUE, TRUE,
                  ## M5
                  FALSE, FALSE, FALSE,                 
                  ## M5Rules
                  FALSE, FALSE,
                  ## mars
                  FALSE, FALSE, 
                  ## mda
                  TRUE,
                  ## Mlda
                  TRUE,
                  ## mlp
                  TRUE,
                  TRUE, TRUE,
                  ## multinom
                  TRUE, 
                  ## nb
                  TRUE, TRUE,
                  ## neuralnet
                  FALSE, FALSE, FALSE, 
                  ## nnet
                  TRUE, TRUE, 
                  ## nodeHarvest
                  TRUE, TRUE,
                  ## obliqueRF
                  TRUE,
                  TRUE,
                  TRUE,
                  TRUE,
                  ## obliqueTree
                  TRUE, TRUE, 
                  ## OneR
                  TRUE, 
                  ## pam
                  TRUE, 
                  ## parRF
                  TRUE, 
                  ## PART
                  TRUE, TRUE, 
                  ## partDSA
                  TRUE, TRUE, 
                  ## pcaNNet
                  TRUE, TRUE, 
                  ## pcr
                  FALSE, 
                  ## pda
                  TRUE, 
                  ## pda2
                  TRUE, 
                  ## penalized
                  FALSE, FALSE,
                  ## PenalizedLDA
                  TRUE, TRUE,
                  ## plr
                  TRUE, TRUE, 
                  ## pls
                  TRUE,
                  ## pls glm binomial
##                  TRUE,
                  ## pls glm Gaussian
##                  FALSE,
                  ## pls glm Gamma
##                  FALSE,
                  ## pls glm Poisson
##                  FALSE,                          
                  ## plsTest
                  TRUE, 
                  ## ppr
                  FALSE,
                  ## protoclass
                  TRUE, TRUE,
                  ## qda
                  TRUE, 
                  ## QdaCov
                  TRUE,
                  ## qrnn
                  FALSE, FALSE, FALSE,                  
                  ## qrf
                  FALSE,
                  ## rbf
                  TRUE,
                  ## rbfDDA
                  TRUE,
                  ## rda
                  TRUE, TRUE, 
                  ## relaxo
                  FALSE, FALSE, 
                  ## rf
                  TRUE,
                  ## rFerns
                  TRUE,
                  ## RFlda
                  TRUE,
                  ## ridge
                  FALSE,
                  ## rlm
                  FALSE, 
                  ## rocc
                  TRUE, 
                  ## rpart
                  TRUE,                  
                  ## rpart2
                  TRUE,
                  ## rpartCost
                  TRUE, TRUE,
                  ## RRF
                  TRUE, TRUE, TRUE,
                  ## RRFglobal
                  TRUE, TRUE,
                  ## rrlda
                  TRUE, TRUE, TRUE,
                  ## rvmLinear
                  FALSE, 
                  ## rvmPoly
                  FALSE, FALSE, 
                  ## rvmRadial
                  FALSE, 
                  ## scrda
                  ## TRUE, TRUE, 
                  ## sda
                  TRUE, TRUE,
                  ## sddaLDA
                  TRUE, 
                  ## sddaQDA
                  TRUE,
                  ## simpls
                  FALSE,                   
                  ## slda
                  TRUE,                 
                  ## smda
                  TRUE, TRUE, TRUE, 
                  ## sparseLDA
                  TRUE, TRUE, 
                  ## spls
                  TRUE, TRUE, TRUE, 
                  ## stepLDA
                  TRUE, TRUE, 
                  ## stepQDA
                  TRUE, TRUE, 
                  ## superpc
                  FALSE, FALSE, 
                  ## svmLinear
                  TRUE, 
                  ## svmpoly
                  TRUE, TRUE, TRUE, 
                  ## svmPoly
                  TRUE, TRUE, TRUE, 
                  ## svmradial
                  TRUE, TRUE, 
                  ## svmRadial
                  TRUE, TRUE, 
                  ## svmRadialCost
                  TRUE,
                  ## svmRadialWeights
                  TRUE, TRUE, TRUE,
                  ## treebag
                  TRUE, 
                  ## vbmpRadial
                  TRUE,
                  ## widekernelpls
                  FALSE,
                  ## xyf
                  TRUE, TRUE, TRUE, TRUE
                  )

  hasProbModel <- c(## ada
                    TRUE, TRUE, TRUE,
                    ## adaboost
                    TRUE, TRUE, TRUE,
                    ## adabag
                    TRUE,                     
                    ## avnnet
                    TRUE, TRUE, TRUE,                     
                    ## bag
                    TRUE, 
                    ## bagEarth
                    TRUE, TRUE, 
                    ## bagFDA
                    TRUE, TRUE,
                    ## bayesglm
                    TRUE,
                    ## bdk
                    TRUE, TRUE, TRUE, TRUE,
                    ## blackboost
                    TRUE, TRUE,
                    ## Boruta
                    TRUE,
                    ## bstTree
                    FALSE, FALSE, FALSE,
                    ## bstLs
                    FALSE, FALSE,
                    ## bstSm
                    FALSE, FALSE,
                    ## C5.0
                    TRUE, TRUE, TRUE,
                    ## C5.0Cost
                    FALSE, FALSE, FALSE, FALSE,                   
                    ## C5.0Tree
                    TRUE,
                    ## C5.0Rules
                    TRUE,
                    ## cforest
                    TRUE, 
                    ## ctree
                    TRUE, 
                    ## ctree2
                    TRUE,
                    ## Cubist
                    FALSE, FALSE,
                    ## earth
                    TRUE, TRUE, 
                    ## earthTest
                    FALSE, FALSE, 
                    ## enet
                    FALSE, FALSE,
                    ## evtree
                    TRUE,
                    ## extraTrees
                    FALSE, FALSE,
                    ## fda
                    TRUE, TRUE, 
                    ## foba
                    FALSE, FALSE,
                    ## gam
                    TRUE, TRUE,
                    ## gamLoess
                    TRUE, TRUE,
                    ## gamSpline
                    TRUE,
                    ## gamboost
                    TRUE, TRUE, 
                    ## gaussprLinear
                    TRUE, 
                    ## gaussprPoly
                    TRUE, TRUE, 
                    ## gaussprRadial
                    TRUE, 
                    ## gbm
                    TRUE, TRUE, TRUE,
                    ## gcvEarth
                    TRUE,
                    ## glm
                    TRUE, 
                    ## glmboost
                    TRUE, TRUE, 
                    ## glmnet
                    TRUE, TRUE, 
                    ## glmrob
##                    TRUE, 
                    ## glmStepAIC
                    TRUE, 
                    ## gpls
                    TRUE, 
                    ## hda
                    TRUE, TRUE, TRUE, 
                    ## hdda
                    TRUE, TRUE, 
                    ## icr
                    FALSE, 
                    ## J48
                    TRUE, 
                    ## JRip
                    TRUE,
                    ## kernelpls
                    TRUE,
                    ## kknn
                    FALSE, FALSE, FALSE,
                    ## knn
                    TRUE,
                    ## krlsRadial
                    FALSE, FALSE,
                    ## krlsPoly
                    FALSE, FALSE,
                    ## lars
                    FALSE, 
                    ## lars2
                    FALSE, 
                    ## lasso
                    FALSE, 
                    ## lda
                    TRUE,
                    ## lda2
                    TRUE,
                    ## leapForward
                    FALSE,
                    ## leapBackward
                    FALSE,
                    ## leapSeq
                    FALSE,
                    ## Linda
                    TRUE, 
                    ## lm
                    FALSE, 
                    ## lmStepAIC
                    FALSE, 
                    ## LMT
                    TRUE, 
                    ## logforest
                    TRUE, 
                    ## logicBag
                    TRUE, TRUE, 
                    ## logitBoost
                    TRUE, 
                    ## logreg
                    TRUE, TRUE,
                    ## lrm
                    TRUE,
                    ## lssvmLinear
                    FALSE, 
                    ## lssvmPoly
                    FALSE, FALSE, 
                    ## lssvmRadial
                    FALSE, 
                    ## lvq
                    FALSE, FALSE,
                    ## M5
                    FALSE, FALSE, FALSE,                    
                    ## M5Rules
                    FALSE, FALSE,
                    ## mars
                    FALSE, FALSE, 
                    ## mda
                    TRUE,
                    ## Mlda
                    FALSE,
                    ## mlp
                    TRUE,
                    TRUE, TRUE,
                    ## multinom
                    TRUE, 
                    ## nb
                    TRUE, TRUE,
                    ## neuralnet
                    FALSE, FALSE, FALSE, 
                    ## nnet
                    TRUE, TRUE, 
                    ## nodeHarvest
                    TRUE, TRUE,
                    ## obliqueRF
                    TRUE,
                    TRUE,
                    TRUE,
                    TRUE,
                    ## obliqueTree
                    TRUE, TRUE, 
                    ## OneR
                    TRUE, 
                    ## pam
                    TRUE, 
                    ## parRF
                    TRUE, 
                    ## PART
                    TRUE, TRUE, 
                    ## partDSA
                    FALSE, FALSE, 
                    ## pcaNNet
                    TRUE, TRUE, 
                    ## pcr
                    FALSE, 
                    ## pda
                    TRUE, 
                    ## pda2
                    TRUE, 
                    ## penalized
                    FALSE, FALSE,
                    ##  PenalizedLDA
                    FALSE, FALSE,
                    ## plr
                    TRUE, TRUE, 
                    ## pls
                    TRUE,
                    ## pls glm binomial
##                    TRUE,
                    ## pls glm Gaussian
##                    FALSE,
                    ## pls glm Gamma
##                    FALSE,
                    ## pls glm Poisson
##                    FALSE,                        
                    ## plsTest
                    TRUE, 
                    ## ppr
                    FALSE,
                    ## protoclass
                    FALSE, FALSE,
                    ## qda
                    TRUE, 
                    ## QdaCov
                    TRUE,
                    ## qrnn
                    FALSE, FALSE, FALSE,                        
                    ## qrf
                    FALSE,
                    ## rbf
                    TRUE,
                    ## rbfDDA
                    TRUE,
                    ## rda
                    TRUE, TRUE, 
                    ## relaxo
                    FALSE, FALSE, 
                    ## rf
                    TRUE,
                    ## rFerns
                    FALSE,
                    ## RFlda
                    FALSE,
                    ## ridge
                    FALSE,
                    ## rlm
                    FALSE, 
                    ## rocc
                    FALSE, 
                    ## rpart
                    TRUE,                    
                    ## rpart2
                    TRUE,
                    ## rpartCost
                    FALSE, FALSE,
                    ## RRF
                    TRUE, TRUE, TRUE,
                    ## RRFglobal
                    TRUE, TRUE,
                    ## rrlda does not generate probabilities, only discrim values
                    FALSE, FALSE, FALSE,
                    ## rvmLinear
                    FALSE, 
                    ## rvmPoly
                    FALSE, FALSE, 
                    ## rvmRadial
                    FALSE, 
                    ## scrda
                    ## TRUE, TRUE, 
                    ## sda
                    TRUE, TRUE,
                    ## sddaLDA
                    TRUE, 
                    ## sddaQDA
                    TRUE,
                    ## simpls
                    FALSE,
                    ## slda
                    TRUE, 
                    ## smda
                    FALSE, FALSE, FALSE, 
                    ## sparseLDA
                    TRUE, TRUE, 
                    ## spls
                    TRUE, TRUE, TRUE, 
                    ## stepLDA
                    TRUE, TRUE, 
                    ## stepQDA
                    TRUE, TRUE, 
                    ## superpc
                    FALSE, FALSE, 
                    ## svmLinear
                    TRUE, 
                    ## svmpoly
                    TRUE, TRUE, TRUE, 
                    ## svmPoly
                    TRUE, TRUE, TRUE, 
                    ## svmradial
                    TRUE, TRUE, 
                    ## svmRadial
                    TRUE, TRUE, 
                    ## svmRadialCost
                    TRUE,
                    ## svmRadialWeights
                    FALSE, FALSE, FALSE,
                    ## treebag
                    TRUE, 
                    ## vbmpRadial
                    TRUE,
                    ## widekernelpls
                    FALSE,
                    ## xyf
                    TRUE, TRUE, TRUE, TRUE
                    )
  
  
  paramKey <- data.frame(model = mods,
                         parameter = pNames,
                         label = pLabel,
                         seq = isSeq,
                         forReg = isRegMod,
                         forClass = isClassMod,
                         probModel = hasProbModel,
                         stringsAsFactors  = FALSE)         
  
  if(!is.null(model))
    {
      if(!any(model == paramKey$model)) stop("value of model unknown")
      out <- paramKey[paramKey$model == model,]
      
    } else out <- paramKey        
  out     

}

if(FALSE)
  {
    ## Some code to clean up the modelLookup data when needed
    
    tt <- caret:::modelLookup()

    tt <- subset(tt, !(model %in% c("plsTest", "earthTest")))

    tt2 <- split(tt, tt$model)

    tt3 <- lapply(tt2,
                  function(x, ind)
                  {
                    mod <- as.character(x$model[1])
                    var <- if(is.logical(x[,ind])) as.character(x[,ind]) else paste('\'', x[,ind], '\'', sep = "")
                    if(names(x)[ind] == "label")
                      {
                        var <- paste(paste(var, ",\n", sep = ""), collapse = "")
                        cat(paste("## ", mod, "\n", var, "" , sep = ""))
                      } else {
                        var <- paste(paste(var, ", ", sep = ""), collapse = "")
                        cat(paste("\n## ", mod, "\n", var, "" , sep = ""))
                      }
                    invisible(var)
                    
                  },
                  ind = 7)

  }
